import factorial
number = int(input("please Enter integer number: "))
r = factorial.factorial(number)
print(r)